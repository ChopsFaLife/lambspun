<?php
require 'vendor/autoload.php';

\Stripe\Stripe::setApiKey('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');

header('Content-Type: application/json');

$YOUR_DOMAIN = 'http://localhost/lambspun';

try {
    $checkout_session = \Stripe\Checkout\Session::create([
        'payment_method_types' => ['card'],
        'line_items' => [[
            'price_data' => [
                'currency' => 'usd',
                'unit_amount' => 2500, // $25.00
                'product_data' => [
                    'name' => 'Lavender Bundle',
                    'description' => 'Hand-crocheted lavender from LambSpun Florals',
                ],
            ],
            'quantity' => 1,
        ]],
        'mode' => 'payment',
        'success_url' => $YOUR_DOMAIN . '/success.html',
        'cancel_url' => $YOUR_DOMAIN . '/cancel.html',
    ]);

    echo json_encode(['id' => $checkout_session->id]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
