<?php
session_start();
require 'db.php';

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$username = $_SESSION['username'];

// Fetch cart items
$stmt = $conn->prepare("SELECT * FROM cart WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

$cart_items = [];
$total_price = 0;
while ($row = $result->fetch_assoc()) {
    $cart_items[] = $row;
    $total_price += $row['price'] * $row['quantity'];
}
$stmt->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>LambSpun Cart</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<h2>Your Cart</h2>

<?php if (count($cart_items) === 0): ?>
    <p>Your cart is empty.</p>
<?php else: ?>
    <table>
        <tr>
            <th>Product</th>
            <th>Price</th>
            <th>Qty</th>
            <th>Total</th>
        </tr>
        <?php foreach ($cart_items as $item): ?>
            <tr>
                <td><?= htmlspecialchars($item['product_name']) ?></td>
                <td>$<?= number_format($item['price'], 2) ?></td>
                <td><?= $item['quantity'] ?></td>
                <td>$<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
            </tr>
        <?php endforeach; ?>
        <tr>
            <td colspan="3" align="right"><strong>Total:</strong></td>
            <td><strong>$<?= number_format($total_price, 2) ?></strong></td>
        </tr>
    </table>

    <br>
    <div id="paypal-button-container"></div>
<?php endif; ?>

<!-- PayPal JS SDK -->
<script src="https://www.paypal.com/sdk/js?client-id=AYMBii00bevmS7IhMW7RNZAIyyYpQK1Z9yxH3DMq10SFM7eU2MYjh4CKgumlzXqMMJblE7tV62vQgGc0&currency=USD"></script>

<script>
paypal.Buttons({
    createOrder: function(data, actions) {
        return actions.order.create({
            purchase_units: [{
                amount: {
                    value: '<?= number_format($total_price, 2) ?>'
                }
            }]
        });
    },
    onApprove: function(data, actions) {
        return actions.order.capture().then(function(details) {
            // Post order to backend
            fetch('log_order.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    username: '<?= $username ?>',
                    cart: <?= json_encode($cart_items) ?>,
                    transaction_id: details.id
                })
            }).then(response => {
                if (response.ok) {
                    alert('Payment successful! Thank you, ' + details.payer.name.given_name);
                    window.location.href = 'account.php';
                } else {
                    alert('Error logging order. Please contact support.');
                }
            });
        });
    }
}).render('#paypal-button-container');
</script>
</body>
</html>
