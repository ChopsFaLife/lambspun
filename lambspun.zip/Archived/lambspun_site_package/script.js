document.addEventListener('DOMContentLoaded', function () {
  const nav = document.querySelector('.nav-container');
  const toggle = document.querySelector('.menu-toggle');

  toggle.addEventListener('click', function () {
    nav.classList.toggle('expanded');
  });
});
