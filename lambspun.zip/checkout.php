<?php
require __DIR__ . '/vendor/autoload.php';

\Stripe\Stripe::setApiKey('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'); // Replace with your real secret test key

header('Content-Type: application/json');

try {
    $session = \Stripe\Checkout\Session::create([
        'payment_method_types' => ['card'],
        'mode' => 'payment',
        'line_items' => [[
            'price_data' => [
                'currency' => 'usd',
                'product_data' => [
                    'name' => 'Lavender Bundle',
                ],
                'unit_amount' => 2500, // $25.00 in cents
            ],
            'quantity' => 1,
        ]],
        'success_url' => 'http://localhost/lambspun/success.html',
        'cancel_url' => 'http://localhost/lambspun/cancel.html',
    ]);

    echo json_encode(['id' => $session->id]);
} catch (\Stripe\Exception\ApiErrorException $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
