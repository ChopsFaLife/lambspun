<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_SESSION['username'];
    $cart_data = json_decode($_POST['cart_data'], true);

    $address1 = $_POST['address_line1'] ?? '';
    $address2 = $_POST['address_line2'] ?? '';
    $city = $_POST['city'] ?? '';
    $state = $_POST['state'] ?? '';
    $zip = $_POST['zip'] ?? '';
    $country = $_POST['country'] ?? '';

    $conn = new mysqli("localhost", "root", "", "lambspun_db");
    if ($conn->connect_error) {
        die("DB Connection failed: " . $conn->connect_error);
    }

    // Save shipping info
    $stmt = $conn->prepare("REPLACE INTO shipping (username, address_line1, address_line2, city, state, zip, country) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $username, $address1, $address2, $city, $state, $zip, $country);
    $stmt->execute();
    $stmt->close();

    // Save each cart item into orders
    $stmt = $conn->prepare("INSERT INTO orders (username, product_name, price) VALUES (?, ?, ?)");
    foreach ($cart_data as $item) {
        $stmt->bind_param("ssd", $username, $item['product_name'], $item['price']);
        $stmt->execute();
    }
    $stmt->close();

    $conn->close();

    echo "✅ Order placed and logged successfully.";
} else {
    echo "No data submitted.";
}
